# NAME

Hoge - It's new $module

# SYNOPSIS

    use Hoge;

# DESCRIPTION

Hoge is ...

# LICENSE

Copyright (C) tokuhirom

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

tokuhirom <tokuhirom@gmail.com>
